//
//  ViewController.swift
//  Transform
//
//  Created by Youk Chansim on 2017. 2. 14..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var layerView: UIView!
    
    @IBOutlet weak var layerView1: UIView!
    @IBOutlet weak var layerView2: UIView!

    @IBOutlet weak var outerLayer: UIView!
    @IBOutlet weak var innerLayer: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let image = UIImage(named: "Snowman")
        layerView.layer.contents = image?.cgImage
        layerView.layer.contentsGravity = kCAGravityResizeAspect
        
//        let tarnsform = CGAffineTransform(rotationAngle: CGFloat(M_PI_4))
//        layerView.layer.setAffineTransform(tarnsform)
        
//        var transform = CGAffineTransform.identity
//        transform = transform.scaledBy(x: 0.5, y: 0.5)
//        transform = transform.rotated(by: CGFloat(M_PI / 180.0 * 30.0))
//        transform = transform.translatedBy(x: 200, y: 0)
//        layerView.layer.setAffineTransform(transform)
        
//        layerView.layer.setAffineTransform(CGAffineTransformMakeShear(x: 1, y: 0))
        
//        var transform = CATransform3DMakeRotation(CGFloat(M_PI_4), 0, 1, 0)
//        layerView.layer.transform = transform
        
//        var transform = CATransform3DIdentity
//        transform.m34 = -1.0 / 500.0
//        transform = CATransform3DRotate(transform, CGFloat(M_PI_4), 0, 1, 0)
//        layerView.layer.transform = transform
        
//        var perspective = CATransform3DIdentity
//        perspective.m34 = -1.0 / 500.0
//        view.layer.sublayerTransform = perspective
//        
//        let transform1 = CATransform3DMakeRotation(CGFloat(M_PI_4), 0, 1, 0)
//        layerView1.layer.transform = transform1
//        layerView1.layer.contents = image?.cgImage
//        
//        let transform2 = CATransform3DMakeRotation(CGFloat(-M_PI_4), 0, 1, 0)
//        layerView2.layer.transform = transform2
//        layerView2.layer.contents = image?.cgImage
        
        var outer = CATransform3DIdentity
        outer.m34 = -1.0 / 500
        let transform1 = CATransform3DRotate(outer, CGFloat(M_PI_4), 0, 1, 0)
        outerLayer.layer.transform = transform1
        
        var inner = CATransform3DIdentity
        inner.m34 = -1.0 / 500
        let transform2 = CATransform3DRotate(inner, CGFloat(-M_PI_4), 0, 1, 0)
        innerLayer.layer.transform = transform2
    }
    
//    func CGAffineTransformMakeShear(x: CGFloat, y: CGFloat) -> CGAffineTransform {
//        var transform = CGAffineTransform.identity
//        transform.c = -x
//        transform.b = y
//        return transform
//    }
}
