//
//  ViewController.swift
//  Transform
//
//  Created by Youk Chansim on 2017. 2. 14..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var layerView: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let image = UIImage(named: "Snowman")
        layerView.layer.contents = image?.cgImage
        layerView.layer.contentsGravity = kCAGravityResizeAspect
        
//        let tarnsform = CGAffineTransform(rotationAngle: CGFloat(M_PI_4))
//        layerView.layer.setAffineTransform(tarnsform)
        
//        var transform = CGAffineTransform.identity
//        transform = transform.scaledBy(x: 0.5, y: 0.5)
//        transform = transform.rotated(by: CGFloat(M_PI / 180.0 * 30.0))
//        transform = transform.translatedBy(x: 200, y: 0)
//        layerView.layer.setAffineTransform(transform)
        
//        layerView.layer.setAffineTransform(CGAffineTransformMakeShear(x: 1, y: 0))
        
//        var transform = CATransform3DMakeRotation(CGFloat(M_PI_4), 0, 1, 0)
//        layerView.layer.transform = transform
        
        var transform = CATransform3DIdentity
        transform.m34 = -1.0 / 500.0
        transform = CATransform3DRotate(transform, CGFloat(M_PI_4), 0, 1, 0)
        layerView.layer.transform = transform
    }
    
//    func CGAffineTransformMakeShear(x: CGFloat, y: CGFloat) -> CGAffineTransform {
//        var transform = CGAffineTransform.identity
//        transform.c = -x
//        transform.b = y
//        return transform
//    }
}
