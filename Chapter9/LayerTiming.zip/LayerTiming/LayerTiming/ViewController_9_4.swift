//
//  ViewController_9_4.swift
//  LayerTiming
//
//  Created by Youk Chansim on 2017. 2. 28..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class ViewController_9_4: UIViewController {
    @IBOutlet weak var containerView: UIView!
    
    let doorLayer = CALayer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        doorLayer.frame = CGRect(x: 0, y: 0, width: 128, height: 128)
        doorLayer.position = CGPoint(x: 100 - 64, y: 100)
        doorLayer.anchorPoint = CGPoint(x: 0, y: 0.5)
        doorLayer.contents = UIImage(named: "Door")?.cgImage
        containerView.layer.addSublayer(doorLayer)
        
        var perspective = CATransform3DIdentity
        perspective.m34 = -1.0 / 500.0
        containerView.layer.sublayerTransform = perspective
        
        let panGesture = UIPanGestureRecognizer(target: self, action: #selector(pan))
        view.addGestureRecognizer(panGesture)
        
        doorLayer.speed = 0
        
        let animation = CABasicAnimation(keyPath: "transform.rotation.y")
        animation.toValue = CGFloat(-M_PI_2)
        animation.duration = 1.0
        doorLayer.add(animation, forKey: nil)
    }
}

extension ViewController_9_4 {
    func pan(gesture: UIPanGestureRecognizer) {
        var x = gesture.translation(in: view).x
        x /= 200.0
        
        var timeOffset = doorLayer.timeOffset
        timeOffset = min(0.999, max(0.0, timeOffset - Double(x)))
        doorLayer.timeOffset = timeOffset
        
        gesture.setTranslation(CGPoint.zero, in: view)
    }
}
