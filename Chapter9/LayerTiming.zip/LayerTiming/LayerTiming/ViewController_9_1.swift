//
//  ViewController.swift
//  LayerTiming
//
//  Created by Youk Chansim on 2017. 2. 26..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class ViewController_9_1: UIViewController {
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var durationField: UITextField!
    @IBOutlet weak var repeatField: UITextField!
    @IBOutlet weak var startButton: UIButton!
    
    @IBAction func startBtnAction(_ sender: Any) {
        let duration = Double(durationField.text ?? "") ?? 0
        let repeatCount = Float(repeatField.text ?? "") ?? 0
        
        let animation = CABasicAnimation(keyPath: "transform.rotation")
        animation.duration = duration
        animation.repeatCount = repeatCount
        animation.byValue = M_PI * 2
        animation.delegate = self
        shipLayer.add(animation, forKey: "rotateAnimation")
        
        setControlsEnabled(enabled: false)
    }

    let shipLayer = CALayer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        shipLayer.frame = CGRect(x: 0, y: 0, width: 128, height: 128)
        shipLayer.position = CGPoint(x: 100, y: 100)
        shipLayer.contents = UIImage(named: "Ship")?.cgImage
        
        containerView.layer.addSublayer(shipLayer)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        
        hideKeyBoard()
    }
}

extension ViewController_9_1 {
    func setControlsEnabled(enabled: Bool) {
        for control: UIControl in [durationField, repeatField, startButton] {
            control.isEnabled = enabled
            control.alpha = enabled ? 1.0 : 0.25
        }
    }
    
    func hideKeyBoard() {
        durationField.resignFirstResponder()
        repeatField.resignFirstResponder()
    }
}

extension ViewController_9_1: CAAnimationDelegate {
    func animationDidStop(_ anim: CAAnimation, finished flag: Bool) {
        setControlsEnabled(enabled: true)
    }
}
