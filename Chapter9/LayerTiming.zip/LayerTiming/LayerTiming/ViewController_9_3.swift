//
//  ViewController_9_3.swift
//  LayerTiming
//
//  Created by Youk Chansim on 2017. 2. 26..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class ViewController_9_3: UIViewController {
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var speedSlider: UISlider!
    @IBOutlet weak var speedLabel: UILabel!
    @IBOutlet weak var timeOffsetSlider: UISlider!
    @IBOutlet weak var timeOffsetLabel: UILabel!

    @IBAction func timeOffsetSliderAction(_ sender: Any) {
        updateTimeOffsetSlider()
    }
    
    @IBAction func speedSliderAction(_ sender: Any) {
        updateSpeedSlider()
    }
    
    @IBAction func playBtnAction(_ sender: Any) {
        let animation = CAKeyframeAnimation(keyPath: "position")
        animation.timeOffset = CFTimeInterval(timeOffsetSlider.value)
        animation.speed = speedSlider.value
        animation.duration = 1.0
        animation.path = bezierPath.cgPath
        animation.rotationMode = kCAAnimationRotateAuto
        animation.isRemovedOnCompletion = false
        shipLayer.add(animation, forKey: "slide")
    }
    
    let shipLayer = CALayer()
    let bezierPath = UIBezierPath()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        bezierPath.move(to: CGPoint(x: 0, y: 100))
        bezierPath.addCurve(to: CGPoint(x: 300, y: 100), controlPoint1: CGPoint(x: 75, y: 100), controlPoint2: CGPoint(x: 225, y: 200))
        
        let pathLayer = CAShapeLayer()
        pathLayer.path = bezierPath.cgPath
        pathLayer.fillColor = UIColor.clear.cgColor
        pathLayer.strokeColor = UIColor.red.cgColor
        pathLayer.lineWidth = 3.0
        containerView.layer.addSublayer(pathLayer)
        
        shipLayer.frame = CGRect(x: 0, y: 0, width: 64, height: 64)
        shipLayer.position = CGPoint(x: 0, y: 100)
        shipLayer.contents = UIImage(named: "Ship")?.cgImage
        containerView.layer.addSublayer(shipLayer)
        
        updateSliders()
    }
}

extension ViewController_9_3 {
    func updateSliders() {
        updateSpeedSlider()
        updateTimeOffsetSlider()
    }
    
    func updateSpeedSlider() {
        let speed = speedSlider.value
        speedLabel.text = String(format: "%0.2f", speed)
    }
    
    func updateTimeOffsetSlider() {
        let timeOffset = timeOffsetSlider.value
        timeOffsetLabel.text = String(format: "%0.2f", timeOffset)
    }
}
