//
//  ViewController_9_2.swift
//  LayerTiming
//
//  Created by Youk Chansim on 2017. 2. 26..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class ViewController_9_2: UIViewController {
    @IBOutlet weak var containerView: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()

        let doorLayer = CALayer()
        doorLayer.frame = CGRect(x: 0, y: 0, width: 128, height: 128)
        doorLayer.position = CGPoint(x: 100 - 64, y: 100)
        doorLayer.anchorPoint = CGPoint(x: 0, y: 0.5)
        doorLayer.contents = UIImage(named: "Door")?.cgImage
        
        containerView.layer.addSublayer(doorLayer)
        
        let animation = CABasicAnimation(keyPath: "transform.rotation.y")
        animation.toValue = CGFloat(-M_PI_2)
        animation.duration = 2.0
        animation.repeatDuration = 100
        animation.autoreverses = true
        
        doorLayer.add(animation, forKey: nil)
    }
}
