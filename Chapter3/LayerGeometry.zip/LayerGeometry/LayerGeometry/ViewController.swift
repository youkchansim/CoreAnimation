//
//  ViewController.swift
//  LayerGeometry
//
//  Created by Naver on 2017. 2. 9..
//  Copyright © 2017년 cs. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var hourHand: UIImageView!
    @IBOutlet weak var minuteHand: UIImageView!
    @IBOutlet weak var secondHand: UIImageView!

    @IBOutlet weak var greenView: UIView!
    @IBOutlet weak var redView: UIView!
    
    @IBOutlet weak var blueView: UIView!
    
    var timer: Timer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        anchoPointExanple()
        zPositionExample()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let point = touches.first?.location(in: view) else { return }
//        let convertPoint = blueView.layer.convert(point, from: view.layer)
//        
//        if blueView.layer.contains(convertPoint) {
//            let alert = UIAlertController(title: "Inside Blue Layer", message: nil, preferredStyle: .alert)
//            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
//            present(alert, animated: true, completion: nil)
//        } else {
//            let alert = UIAlertController(title: "Inside Other Layer", message: nil, preferredStyle: .alert)
//            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
//            present(alert, animated: true, completion: nil)
//        }
        
        let layer = view.layer.hitTest(point)
        if layer == blueView.layer {
            let alert = UIAlertController(title: "Inside Blue Layer", message: nil, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        } else {
            let alert = UIAlertController(title: "Inside Other Layer", message: nil, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }
    }
}

extension ViewController {
    func anchoPointExanple() {
        hourHand.layer.anchorPoint = CGPoint(x: 0.5, y: 0.9)
        minuteHand.layer.anchorPoint = CGPoint(x: 0.5, y: 0.9)
        secondHand.layer.anchorPoint = CGPoint(x: 0.5, y: 0.9)
        
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(tick), userInfo: nil, repeats: true)
        
        tick()
    }
    
    func tick() {
        let calendar = Calendar(identifier: .gregorian)
        let units: Set<Calendar.Component> = [.hour, .minute, .second]
        let components = calendar.dateComponents(units, from: Date())
        
        let hourAngle = Double(components.hour ?? 0) / 12.0 * M_PI * 2.0
        let minuteAngle = Double(components.minute ?? 0) / 60.0 * M_PI * 2.0
        let secondAngle = Double(components.second ?? 0) / 60.0 * M_PI * 2.0
        
        hourHand.transform = CGAffineTransform(rotationAngle: CGFloat(hourAngle))
        minuteHand.transform = CGAffineTransform(rotationAngle: CGFloat(minuteAngle))
        secondHand.transform = CGAffineTransform(rotationAngle: CGFloat(secondAngle))
    }
}

extension ViewController {
    func zPositionExample() {
        greenView.layer.zPosition = 1.0
    }
}
