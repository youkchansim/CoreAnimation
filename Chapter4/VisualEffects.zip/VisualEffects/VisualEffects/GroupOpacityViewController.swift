//
//  GroupOpacityViewController.swift
//  VisualEffects
//
//  Created by Youk Chansim on 2017. 2. 13..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class GroupOpacityViewController: UIViewController {

    @IBAction func backButton(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var view2: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        view2.layer.shouldRasterize = true
        view2.layer.rasterizationScale = UIScreen.main.scale
    }
}
