//
//  LayerMaskViewController.swift
//  VisualEffects
//
//  Created by Youk Chansim on 2017. 2. 13..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class LayerMaskViewController: UIViewController {

    @IBAction func backButton(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let maskLayer = CALayer()
        maskLayer.frame = imageView.frame
        let image = UIImage(named: "Cone")
        maskLayer.contents = image?.cgImage
        
        imageView.layer.mask = maskLayer
    }
}
