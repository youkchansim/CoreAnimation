//
//  ShadowPathViewController.swift
//  VisualEffects
//
//  Created by Youk Chansim on 2017. 2. 13..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class ShadowPathViewController: UIViewController {
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var view2: UIView!

    @IBAction func backButton(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        view1.layer.shadowOpacity = 0.5
        view2.layer.shadowOpacity = 0.5
        
        let squarePath = CGMutablePath()
        squarePath.addRect(view1.bounds)
        view1.layer.shadowPath = squarePath
        
        let circlePath = CGMutablePath()
        circlePath.addEllipse(in: view2.bounds)
        view2.layer.shadowPath = circlePath
    }
}
