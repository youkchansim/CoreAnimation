//
//  LayerBordersViewController.swift
//  VisualEffects
//
//  Created by Youk Chansim on 2017. 2. 13..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class LayerBordersViewController: UIViewController {
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var shadowView: UIView!

    @IBAction func backButton(_ sender: Any) {
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        view1.layer.cornerRadius = 20
        view2.layer.cornerRadius = 20
        
        view1.layer.borderWidth = 5
        view2.layer.borderWidth = 5
        
        view1.layer.shadowOpacity = 0.5
        view1.layer.shadowOffset = CGSize(width: 0, height: 5)
        view1.layer.shadowRadius = 5
        
        shadowView.layer.shadowOpacity = 0.5
        shadowView.layer.shadowOffset = CGSize(width: 0, height: 5)
        shadowView.layer.shadowRadius = 5
        
        view2.layer.masksToBounds = true
    }
}
