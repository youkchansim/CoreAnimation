//
//  ScalingFiltersViewController.swift
//  VisualEffects
//
//  Created by Youk Chansim on 2017. 2. 13..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class ScalingFiltersViewController: UIViewController {

    @IBOutlet var views: [UIView]!
    
    var timer: Timer?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let image = UIImage(named: "Digits")
        
        views.forEach {
            $0.layer.contents = image?.cgImage
            $0.layer.contentsRect = CGRect(x: 0, y: 0, width: 0.1, height: 1.0)
            $0.layer.contentsGravity = kCAGravityResizeAspect
//            $0.layer.magnificationFilter = kCAFilterNearest
        }
        
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(tick), userInfo: nil, repeats: true)
        
        tick()
    }
    
    func setDigit(digit: Int, view: UIView) {
        view.layer.contentsRect = CGRect(x: CGFloat(digit / 10), y: 0, width: 0.1, height: 1.0)
    }
    
    func tick() {
        let calendar = NSCalendar(calendarIdentifier: .gregorian)
        
        let units: NSCalendar.Unit = [.hour, .minute, .second]
        
        let components = calendar?.components(units, from: Date())
        
        setDigit(digit: components?.hour ?? 0 / 10, view: views[0])
        setDigit(digit: components?.hour ?? 0 % 10, view: views[1])
        
        setDigit(digit: components?.minute ?? 0 / 10, view: views[2])
        setDigit(digit: components?.minute ?? 0 % 10, view: views[3])
        
        setDigit(digit: components?.second ?? 0 / 10, view: views[4])
        setDigit(digit: components?.second ?? 0 % 10, view: views[5])
    }
}
