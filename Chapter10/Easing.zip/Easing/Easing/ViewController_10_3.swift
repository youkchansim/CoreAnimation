//
//  ViewController_10_3.swift
//  Easing
//
//  Created by Youk Chansim on 2017. 3. 5..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class ViewController_10_3: UIViewController {
    @IBOutlet weak var layerView: UIView!

    let colorLayer = CALayer()
    
    @IBAction func changeColor(_ sender: Any) {
        let animation = CAKeyframeAnimation(keyPath: "backgroundColor")
        animation.duration = 2.0
        animation.values = [
            UIColor.blue.cgColor,
            UIColor.red.cgColor,
            UIColor.green.cgColor,
            UIColor.blue.cgColor,
        ]
        
        let fn = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseIn)
        animation.timingFunctions = [fn, fn, fn]
        
        colorLayer.add(animation, forKey: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        colorLayer.frame = CGRect(x: 50, y: 50, width: 100, height: 100)
        colorLayer.backgroundColor = UIColor.blue.cgColor
        
        layerView.layer.addSublayer(colorLayer)
    }
}

