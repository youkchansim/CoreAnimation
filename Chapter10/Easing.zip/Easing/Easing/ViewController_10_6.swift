//
//  ViewController_10_6.swift
//  Easing
//
//  Created by Youk Chansim on 2017. 3. 7..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class ViewController_10_6: UIViewController {
    @IBOutlet weak var ballView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ballView.image = UIImage(named: "Ball")
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        animate()
    }
}

extension ViewController_10_6 {
    func interpolate(from: CGFloat, to: CGFloat, time: CGFloat) -> CGFloat {
        return (to - from) * time + from
    }
    
    func interpolateFromValue(fromValue: Any, toValue: Any, time: CGFloat) -> Any {
        if let fromPoint = fromValue as? CGPoint, let toPoint = toValue as? CGPoint {
            let result = CGPoint(x: interpolate(from: fromPoint.x, to: toPoint.x, time: time), y: interpolate(from: fromPoint.y, to: toPoint.y, time: time))
            return NSValue(cgPoint: result)
        }
        
        return time < 0.5 ? fromValue : toValue
    }
    
    func animate() {
        let fromValue = NSValue(cgPoint: CGPoint(x: 120, y: 32))
        let toValue = NSValue(cgPoint: CGPoint(x: 120, y: 268))
        let duration: CFTimeInterval = 1.0
        
        let numFrames = duration * 60
        var frames: [Any] = []
        
        for i in 0..<Int(numFrames) {
            let time = 1.0 / numFrames * Double(i)
            frames.append(interpolateFromValue(fromValue: fromValue, toValue: toValue, time: CGFloat(time)))
        }
        
        let animation = CAKeyframeAnimation(keyPath: "position")
        animation.duration = 1.0
        animation.values = frames
        ballView.layer.add(animation, forKey: nil)
    }
}
