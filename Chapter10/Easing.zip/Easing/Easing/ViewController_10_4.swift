//
//  ViewController_10_4.swift
//  Easing
//
//  Created by Youk Chansim on 2017. 3. 6..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

struct TimingFuncType {
    private init() {}
    
    static let EaseOut = kCAMediaTimingFunctionEaseOut
    static let EaseIn = kCAMediaTimingFunctionEaseIn
    static let EaseIneaseOut = kCAMediaTimingFunctionEaseInEaseOut
    static let Linear = kCAMediaTimingFunctionLinear
    static let Default = kCAMediaTimingFunctionDefault
}

class ViewController_10_4: UIViewController {
    @IBOutlet weak var layerView: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let function = CAMediaTimingFunction(name: TimingFuncType.EaseIneaseOut)
        
        let controlPoint1 = UnsafeMutablePointer<Float>.allocate(capacity: 2)
        let controlPoint2 = UnsafeMutablePointer<Float>.allocate(capacity: 2)
        
        function.getControlPoint(at: 1, values: controlPoint1)
        function.getControlPoint(at: 2, values: controlPoint2)
        
        let path = UIBezierPath()
        path.move(to: CGPoint.zero)
        path.addCurve(to: CGPoint(x: 1, y: 1),
                      controlPoint1: CGPoint(x: CGFloat(controlPoint1[0]), y: CGFloat(controlPoint1[1])),
                      controlPoint2: CGPoint(x: CGFloat(controlPoint2[0]), y: CGFloat(controlPoint2[1]))
        )
        
        path.apply(CGAffineTransform(scaleX: 200, y: 200))
        
        let shapeLayer = CAShapeLayer()
        shapeLayer.strokeColor = UIColor.red.cgColor
        shapeLayer.fillColor = UIColor.clear.cgColor
        shapeLayer.lineWidth = 4.0
        shapeLayer.path = path.cgPath
        layerView.layer.addSublayer(shapeLayer)
        
        layerView.layer.isGeometryFlipped = true
    }
}
