//
//  ViewController_10_2.swift
//  Easing
//
//  Created by Youk Chansim on 2017. 3. 5..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class ViewController_10_2: UIViewController {
    @IBOutlet weak var colorView: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()

        colorView.backgroundColor = .red
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        UIView.animate(withDuration: 1.0, delay: 0.0, options: [.curveEaseInOut], animations: {
            guard let location = touches.first?.location(in: self.view) else { return }
            self.colorView.center = location
        }, completion: nil)
    }
}
