//
//  ViewController_10_7.swift
//  Easing
//
//  Created by Youk Chansim on 2017. 3. 7..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class ViewController_10_7: UIViewController {
    @IBOutlet weak var ballView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ballView.image = UIImage(named: "Ball")
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        animate()
    }
}

extension ViewController_10_7 {
    func interpolate(from: CGFloat, to: CGFloat, time: CGFloat) -> CGFloat {
        return (to - from) * time + from
    }
    
    func interpolateFromValue(fromValue: Any, toValue: Any, time: CGFloat) -> Any {
        if let fromPoint = fromValue as? CGPoint, let toPoint = toValue as? CGPoint {
            let result = CGPoint(x: interpolate(from: fromPoint.x, to: toPoint.x, time: time), y: interpolate(from: fromPoint.y, to: toPoint.y, time: time))
            return NSValue(cgPoint: result)
        }
        
        return time < 0.5 ? fromValue : toValue
    }
    
    func quadraticEaseInOut(t: CGFloat) -> CGFloat {
        return t < 0.5 ? (2 * t * t) : (-2 * t * t) + (4 * t) - 1
    }
    
    func bounceEaseOut(t: CGFloat) -> CGFloat {
        if t < 4 / 11.0 {
            return (121 * t * t) / 16.0
        } else if (t < 8 / 11.0) {
            return (363 / 40.0 * t * t) - (99 / 10.0 * t) + 17 / 5.0
        } else if (t < 9/10.0) {
            return (4356 / 361.0 * t * t) - (35442 / 1805.0 * t) + 16061 / 1805.0
        }
        
        return (54 / 5.0 * t * t) - (513 / 25.0 * t) + 268 / 25.0;
    }
    
    func animate() {
        let fromValue = NSValue(cgPoint: CGPoint(x: 120, y: 32))
        let toValue = NSValue(cgPoint: CGPoint(x: 120, y: 268))
        let duration: CFTimeInterval = 1.0
        
        let numFrames = duration * 60
        var frames: [Any] = []
        
        for i in 0..<Int(numFrames) {
            var time = CGFloat(1.0 / numFrames * Double(i))
            
            time = bounceEaseOut(t: CGFloat(time))
            
            frames.append(interpolateFromValue(fromValue: fromValue, toValue: toValue, time: time))
        }
        
        let animation = CAKeyframeAnimation(keyPath: "position")
        animation.duration = 3.0
        animation.values = frames
        ballView.layer.add(animation, forKey: nil)
    }
}
