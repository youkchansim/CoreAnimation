//
//  ViewController.swift
//  Easing
//
//  Created by Youk Chansim on 2017. 3. 1..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class ViewController_10_1: UIViewController {
    let colorLayer = CALayer()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        colorLayer.frame = CGRect(x: 0, y: 0, width: 100, height: 100)
        colorLayer.position = CGPoint(x: view.bounds.size.width / 2, y: view.bounds.size.width / 2)
        colorLayer.backgroundColor = UIColor.red.cgColor
        view.layer.addSublayer(colorLayer)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        
        CATransaction.begin()
        CATransaction.setAnimationDuration(1.0)
        CATransaction.setAnimationTimingFunction(CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseOut))
        
        colorLayer.position = touches.first?.location(in: view) ?? colorLayer.position
        
        CATransaction.commit()
    }
}
