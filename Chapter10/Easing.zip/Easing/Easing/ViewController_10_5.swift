//
//  ViewController_10_5.swift
//  Easing
//
//  Created by Youk Chansim on 2017. 3. 7..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class ViewController_10_5: UIViewController {
    @IBOutlet weak var ballView: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()

        ballView.image = UIImage(named: "Ball")
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        animate()
    }
}

extension ViewController_10_5 {
    func animate() {
        let animation = CAKeyframeAnimation(keyPath: "position")
        animation.duration = 3.0
        animation.delegate = self
        animation.values = [
            NSValue(cgPoint: CGPoint(x: 120, y: 32)),
            NSValue(cgPoint: CGPoint(x: 120, y: 268)),
            NSValue(cgPoint: CGPoint(x: 120, y: 140)),
            NSValue(cgPoint: CGPoint(x: 120, y: 268)),
            NSValue(cgPoint: CGPoint(x: 120, y: 220)),
            NSValue(cgPoint: CGPoint(x: 120, y: 268)),
            NSValue(cgPoint: CGPoint(x: 120, y: 250)),
            NSValue(cgPoint: CGPoint(x: 120, y: 268)),
        ]
        
        animation.timingFunctions = [
            CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseIn),
            CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseOut),
            CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseIn),
            CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseOut),
            CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseIn),
            CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseOut),
            CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseIn),
        ]
        
        animation.keyTimes = [0.0, 0.3, 0.5, 0.7, 0.8, 0.9, 0.95, 1.0]
        ballView.layer.add(animation, forKey: nil)
    }
}

extension ViewController_10_5: CAAnimationDelegate {
    
}
