//
//  ViewController_13_3.swift
//  EfficientDrawing
//
//  Created by Youk Chansim on 2017. 4. 1..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class ViewController_13_3: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}

class DrawingView_13_3: UIView {
    
    let BRUSH_SIZE: CGFloat = 32
    var strokes: [CGPoint] = []
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let point = touches.first?.location(in: self) {
            addBurshStrokePoint(point: point)
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let point = touches.first?.location(in: self) {
            addBurshStrokePoint(point: point)
        }
    }
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)
        for stroke in strokes {
            let brushRect = CGRect(x: stroke.x - BRUSH_SIZE / 2, y: stroke.y - BRUSH_SIZE / 2, width: BRUSH_SIZE, height: BRUSH_SIZE)
            let image = #imageLiteral(resourceName: "Chalk")
            image.draw(in: brushRect)
        }
    }
}

extension DrawingView_13_4 {
    func addBurshStrokePoint(point: CGPoint) {
        strokes.append(point)
        setNeedsDisplay()
    }
}

class DrawingView_13_4: UIView {
    
    let BRUSH_SIZE: CGFloat = 32
    var strokes: [CGPoint] = []
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let point = touches.first?.location(in: self) {
            addBurshStrokePoint(point: point)
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let point = touches.first?.location(in: self) {
            addBurshStrokePoint(point: point)
        }
    }
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)
        for stroke in strokes {
            let brushRect = CGRect(x: stroke.x - BRUSH_SIZE / 2, y: stroke.y - BRUSH_SIZE / 2, width: BRUSH_SIZE, height: BRUSH_SIZE)
            let image = #imageLiteral(resourceName: "Chalk")
            image.draw(in: brushRect)
        }
    }
}

extension DrawingView_13_3 {
    func addBurshStrokePoint(point: CGPoint) {
        strokes.append(point)
        setNeedsDisplay(brushRectForPoint(point: point))
    }
    
    func brushRectForPoint(point: CGPoint) -> CGRect {
        return CGRect(x: point.x - BRUSH_SIZE / 2, y: point.y - BRUSH_SIZE / 2, width: BRUSH_SIZE, height: BRUSH_SIZE)
    }
}
