//
//  ViewController.swift
//  EfficientDrawing
//
//  Created by Youk Chansim on 2017. 3. 30..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class ViewController_13_1: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()

    }
}

class DrawingView: UIView {
    let path = UIBezierPath()
    
    override class var layerClass: AnyClass {
        return CAShapeLayer.self
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        if let layer = self.layer as? CAShapeLayer {
            let shapeLayer: CAShapeLayer = layer
            shapeLayer.strokeColor = UIColor.red.cgColor
            shapeLayer.fillColor = UIColor.clear.cgColor
            shapeLayer.lineJoin = kCALineJoinRound
            shapeLayer.lineCap = kCALineCapRound
            shapeLayer.lineWidth = 5
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let point = touches.first?.location(in: self) {
            path.move(to: point)
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let point = touches.first?.location(in: self) {
            path.addLine(to: point)
            if let layer = self.layer as? CAShapeLayer {
                layer.path = self.path.cgPath
            }
        }
    }
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)
        UIColor.clear.setFill()
        UIColor.red.setStroke()
        path.stroke()
    }
}
