//
//  _8_13_ViewController.swift
//  ExplicitAnimations
//
//  Created by Youk Chansim on 2017. 2. 23..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class _8_13_ViewController: UIViewController {
    @IBAction func performTransition(_ sender: Any) {
        UIGraphicsBeginImageContextWithOptions(view.bounds.size, true, 0.0)
        view.layer.render(in: UIGraphicsGetCurrentContext()!)
        let coverImage = UIGraphicsGetImageFromCurrentImageContext()
        
        let coverView = UIImageView(image: coverImage)
        coverView.frame = view.bounds
        view.addSubview(coverView)
        
        let red = CGFloat(arc4random()) / CGFloat(INT_MAX)
        let green = CGFloat(arc4random()) / CGFloat(INT_MAX)
        let blue = CGFloat(arc4random()) / CGFloat(INT_MAX)
        view.backgroundColor = UIColor(red: red, green: green, blue: blue, alpha: 1.0)
        
        UIView.animate(withDuration: 1.0, animations: {
            var transform = CGAffineTransform.init(scaleX: 0.01, y: 0.01)
            transform = transform.rotated(by: CGFloat(M_PI_2))
            coverView.transform = transform
            coverView.alpha = 0.0
        }, completion: { _ in
            coverView.removeFromSuperview()
        })
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
