//
//  _8_12_ViewController.swift
//  ExplicitAnimations
//
//  Created by Youk Chansim on 2017. 2. 23..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class _8_12_ViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    override func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        let transition = CATransition()
        transition.type = kCATransitionFade
        
        view.layer.add(transition, forKey: nil)
    }
}
