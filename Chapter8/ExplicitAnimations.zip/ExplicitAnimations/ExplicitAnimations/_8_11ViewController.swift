//
//  8_11ViewController.swift
//  ExplicitAnimations
//
//  Created by Youk Chansim on 2017. 2. 21..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class _8_11ViewController: UIViewController {
    @IBOutlet weak var imageView: UIImageView!
    @IBAction func switchImageBtnAction(_ sender: Any) {
        UIView.transition(with: imageView, duration: 1.0, options: [.transitionFlipFromLeft, .curveEaseInOut], animations: {
            if let currentImage = self.imageView.image {
                var index = self.images.index(of: currentImage) ?? 0
                index = (index + 1) % self.images.count
                self.imageView.image = self.images[index]
            }
        }, completion: nil)
//        let transition = CATransition()
//        transition.type = kCATransitionReveal
//        
//        imageView.layer.add(transition, forKey: nil)
//        
//        if let currentImage = imageView.image {
//            var index = images.index(of: currentImage) ?? 0
//            index = (index + 1) % images.count
//            imageView.image = images[index]
//        }
    }

    var images: [UIImage] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        images = [
            UIImage(named: "Anchor")!,
            UIImage(named: "Cone")!,
            UIImage(named: "Igloo")!,
            UIImage(named: "Spaceship")!,
        ]
    }
}
