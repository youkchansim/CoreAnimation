//
//  _8_14_ViewController.swift
//  ExplicitAnimations
//
//  Created by Youk Chansim on 2017. 2. 23..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class _8_14_ViewController: UIViewController {
    @IBOutlet weak var containerView: UIView!

    @IBAction func start(_ sender: Any) {
        let animation = CABasicAnimation(keyPath: "transform.rotation")
        animation.duration = 2.0
        animation.byValue = M_PI * 2
        animation.delegate = self
        shipLayer.add(animation, forKey: "rotateAnimation")
    }
    
    @IBAction func stop(_ sender: Any) {
        shipLayer.removeAnimation(forKey: "rotateAnimation")
    }
    
    let shipLayer = CALayer()
    override func viewDidLoad() {
        super.viewDidLoad()

        shipLayer.frame = CGRect(x: 0, y: 0, width: 128, height: 128)
        shipLayer.position = CGPoint(x: 100, y: 100)
        shipLayer.contents = UIImage(named: "Ship")?.cgImage
        
        containerView.layer.addSublayer(shipLayer)
    }
}

extension _8_14_ViewController: CAAnimationDelegate {
    func animationDidStop(_ anim: CAAnimation, finished flag: Bool) {
        print(flag)
    }
}
