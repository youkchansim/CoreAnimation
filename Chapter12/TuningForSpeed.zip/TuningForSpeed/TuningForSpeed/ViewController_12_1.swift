//
//  ViewController.swift
//  TuningForSpeed
//
//  Created by Youk Chansim on 2017. 3. 28..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

struct SampleModel {
    var name: String
    var image: UIImage
}

class ViewController_12_1: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    
    var items: [SampleModel] = []
    
    var firstName = ["Alice", "Bob", "Charles", "Dan", "Dave", "Ethan", "Frank", "육"]
    var lastName = ["Appleseed", "Bandicoot", "Caravan", "Dabble", "Ernest", "Fortune", "찬심"]
    var images = [#imageLiteral(resourceName: "Snowman"), #imageLiteral(resourceName: "Igloo"), #imageLiteral(resourceName: "Cone"), #imageLiteral(resourceName: "Spaceship"), #imageLiteral(resourceName: "Anchor"), #imageLiteral(resourceName: "Key")]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        
        items = (1...1000).map { _ in
            generateRandomModel()
        }
    }
}

extension ViewController_12_1 {
    func generateRandomModel() -> SampleModel {
        return SampleModel(name: generateRandomName(), image: generateRandomImage())
    }
    
    private func generateRandomName() -> String {
        let firstIndex = Int(arc4random()) % firstName.count
        let lastIndex = Int(arc4random()) % lastName.count
        
        return "\(firstName[firstIndex]) \(lastName[lastIndex])"
    }
    
    private func generateRandomImage() -> UIImage {
        let index = Int(arc4random()) % images.count
        return images[index]
    }
}

extension ViewController_12_1: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell_12", for: indexPath) as? TableViewCell_12 else {
            return UITableViewCell()
        }
        
        let item = items[indexPath.row]
        cell.imageV.image = item.image
        cell.textL.text = item.name
        
        cell.imageV.layer.shadowOffset = CGSize(width: 0, height: 5)
        cell.imageV.layer.shadowOpacity = 0.75
        cell.clipsToBounds = true
        
        cell.textL.backgroundColor = .clear
        cell.textL.layer.shadowOffset = CGSize(width: 0, height: 2)
        cell.textL.layer.shadowOpacity = 0.5

        cell.layer.shouldRasterize = true
        cell.layer.rasterizationScale = UIScreen.main.scale
        
        return cell
    }
}
