//
//  TableViewCell_12.swift
//  TuningForSpeed
//
//  Created by Youk Chansim on 2017. 3. 28..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class TableViewCell_12: UITableViewCell {
    @IBOutlet weak var imageV: UIImageView!
    @IBOutlet weak var textL: UILabel!
}
