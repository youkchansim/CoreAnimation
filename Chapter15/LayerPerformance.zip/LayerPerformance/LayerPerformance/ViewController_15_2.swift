//
//  ViewController_15_2.swift
//  LayerPerformance
//
//  Created by Youk Chansim on 2017. 4. 16..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class ViewController_15_2: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        let blueLayer = CALayer()
        blueLayer.frame = CGRect(x: 50, y: 50, width: 100, height: 100)
        blueLayer.contentsCenter = CGRect(x: 0.5, y: 0.5, width: 0, height: 0)
        blueLayer.contentsScale = UIScreen.main.scale
        blueLayer.contents = #imageLiteral(resourceName: "Rounded").cgImage
        
        view.layer.addSublayer(blueLayer)
    }
}
