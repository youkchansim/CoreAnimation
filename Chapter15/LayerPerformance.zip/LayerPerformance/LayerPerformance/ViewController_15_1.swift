//
//  ViewController.swift
//  LayerPerformance
//
//  Created by Youk Chansim on 2017. 4. 16..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class ViewController_15_1: UIViewController {
    @IBOutlet weak var layerView: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let blueLayer = CAShapeLayer()
        blueLayer.frame = CGRect(x: 0, y: 0, width: 100, height: 100)
        blueLayer.position = layerView.layer.position
        blueLayer.fillColor = UIColor.blue.cgColor
        blueLayer.path = UIBezierPath(roundedRect: CGRect(x: 0, y: 0, width: 100, height: 100), cornerRadius: 20).cgPath
        
        layerView.layer.addSublayer(blueLayer)
    }
}
