//
//  ViewController_15_4.swift
//  LayerPerformance
//
//  Created by Youk Chansim on 2017. 4. 16..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit
import QuartzCore

let WIDTH = 100
let HEIGHT = 100
let DEPTH = 10

let SIZE = 100
let SPACING = 150

let CAMERA_DISTANCE = 500

let PERSPECTIVE: (CGFloat) -> CGFloat = {
    return CGFloat(CAMERA_DISTANCE) / ($0 + CGFloat(CAMERA_DISTANCE))
}

class ViewController_15_4: UIViewController {
    @IBOutlet weak var scrollView: UIScrollView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        scrollView.contentSize = CGSize(width: (WIDTH - 1) * SPACING, height: (HEIGHT - 1) * SPACING)
        
        var transform = CATransform3DIdentity
        transform.m34 = -1.0 / CGFloat(CAMERA_DISTANCE)
        scrollView.layer.sublayerTransform = transform
        
        print("\(DEPTH * HEIGHT * WIDTH)")
    }
    
    override func viewDidLayoutSubviews() {
        updateLayers()
    }
    
    func updateLayers() {
        var bounds = scrollView.bounds
        bounds.origin = scrollView.contentOffset
        bounds = bounds.insetBy(dx: CGFloat(-SIZE / 2), dy: CGFloat(-SIZE / 2))
        
        var visibleLayers: [CALayer] = []
        
        for z in (0 ..< DEPTH).reversed() {
            var adjusted = bounds
            adjusted.size.width /= PERSPECTIVE(CGFloat(z * SPACING))
            adjusted.size.height /= PERSPECTIVE(CGFloat(z * SPACING))
            adjusted.origin.x = (adjusted.size.width - bounds.size.width) / 2
            adjusted.origin.y = (adjusted.size.height - bounds.size.height) / 2
            
            for y in 0 ..< HEIGHT {
                if CGFloat(y * SPACING) < adjusted.origin.y || CGFloat(y * SPACING) >= adjusted.origin.y + adjusted.size.height {
                    continue
                }
                
                for x in 0 ..< WIDTH {
                    if CGFloat(x * SPACING) < adjusted.origin.x || CGFloat(x * SPACING) >= adjusted.origin.x + adjusted.size.width {
                        continue
                    }
                    
                    let layer = CALayer()
                    layer.frame = CGRect(x: 0, y: 0, width: SIZE, height: SIZE)
                    layer.position = CGPoint(x: x * SPACING, y: y * SPACING)
                    layer.zPosition = CGFloat(-z * SPACING)
                    layer.backgroundColor = UIColor(white: CGFloat(1 - CGFloat(z) * (1.0 / CGFloat(DEPTH))), alpha: 1).cgColor
                    
                    visibleLayers.append(layer)
                }
            }
        }
        
        scrollView.layer.sublayers = visibleLayers
    }
}

extension ViewController_15_4: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        updateLayers()
    }
}
