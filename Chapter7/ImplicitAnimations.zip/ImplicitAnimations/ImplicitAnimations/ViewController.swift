//
//  ViewController.swift
//  ImplicitAnimations
//
//  Created by Youk Chansim on 2017. 2. 14..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var layerView: UIView!

    @IBAction func buttonAction(_ sender: Any) {
//        CATransaction.begin()
//        CATransaction.setAnimationDuration(1.0)
//        CATransaction.setCompletionBlock {
//            var transform = self.layer.affineTransform()
//            transform = transform.rotated(by: CGFloat(M_PI_2))
//            self.layer.setAffineTransform(transform)
//        }
        
        if flag == 0 {
            flag = 1
            changeColor()
        } else {
            flag = 0
            changeColorToWhite()
        }
        
//        CATransaction.commit()
    }

    var layer = CALayer()
    var flag = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        layer.frame = CGRect(x: 0, y: 0, width: 100, height: 100)
        layer.position = CGPoint(x: view.bounds.size.width / 2, y: view.bounds.size.height / 2)
        layer.backgroundColor = UIColor.blue.cgColor
        view.layer.addSublayer(layer)
        
//        let transition = CATransition()
//        transition.type = kCATransitionPush
//        transition.subtype = kCATransitionFromLeft
//        layer.actions = ["backgroundColor": transition]
//        layerView.layer.addSublayer(layer)
//        layerView.layer.backgroundColor = UIColor.blue.cgColor
        
//        print(layerView.action(for: layerView.layer, forKey: "backgroundColor") ?? "nil")
//        
//        UIView.beginAnimations(nil, context: nil)
//        print(layerView.action(for: layerView.layer, forKey: "backgroundColor") ?? "nil")
//        UIView.commitAnimations()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let point = touches.first?.location(in: view) else { return }
        
        if layer.presentation()?.hitTest(point) != nil {
            let red = CGFloat(arc4random()) / CGFloat(INT_MAX)
            let green = CGFloat(arc4random()) / CGFloat(INT_MAX)
            let blue = CGFloat(arc4random()) / CGFloat(INT_MAX)
            
            layer.backgroundColor = UIColor(red: red, green: green, blue: blue, alpha: 1.0).cgColor
        } else {
            CATransaction.begin()
            CATransaction.setAnimationDuration(4)
            layer.position = point
            CATransaction.commit()
        }
    }
    
    func changeColor() {
        let red = CGFloat(arc4random()) / CGFloat(INT_MAX)
        let green = CGFloat(arc4random()) / CGFloat(INT_MAX)
        let blue = CGFloat(arc4random()) / CGFloat(INT_MAX)
        
//        layer.backgroundColor = UIColor(red: red, green: green, blue: blue, alpha: 1.0).cgColor
        layer.backgroundColor = UIColor(red: red, green: green, blue: blue, alpha: 1.0).cgColor
    }
    
    func changeColorToWhite() {
        layer.backgroundColor = UIColor.white.cgColor
    }
}
