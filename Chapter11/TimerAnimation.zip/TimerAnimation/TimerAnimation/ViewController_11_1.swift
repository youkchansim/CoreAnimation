//
//  ViewController.swift
//  TimerAnimation
//
//  Created by Youk Chansim on 2017. 3. 9..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class ViewController_11_1: UIViewController {
    @IBOutlet weak var ballView: UIImageView!
    
    var timer: Timer?
    var duration: TimeInterval = 0
    var timeOffset: TimeInterval = 0
    var fromValue: Any = NSValue(cgPoint: CGPoint.zero)
    var toValue: Any = NSValue(cgPoint: CGPoint.zero)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ballView.image = UIImage(named: "Ball")
        
        animate()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        animate()
    }
}

extension ViewController_11_1 {
    func interpolate(from: CGFloat, to: CGFloat, time: CGFloat) -> CGFloat {
        return (to - from) * time + from
    }
    
    func interpolateFromValue(fromValue: Any, toValue: Any, time: CGFloat) -> Any {
        if let fromPoint = fromValue as? CGPoint, let toPoint = toValue as? CGPoint {
            let result = CGPoint(x: interpolate(from: fromPoint.x, to: toPoint.x, time: time), y: interpolate(from: fromPoint.y, to: toPoint.y, time: time))
            return NSValue(cgPoint: result)
        }
        
        return time < 0.5 ? fromValue : toValue
    }
    
    func quadraticEaseInOut(t: CGFloat) -> CGFloat {
        return t < 0.5 ? (2 * t * t) : (-2 * t * t) + (4 * t) - 1
    }
    
    func bounceEaseOut(t: CGFloat) -> CGFloat {
        if t < 4 / 11.0 {
            return (121 * t * t) / 16.0
        } else if (t < 8 / 11.0) {
            return (363 / 40.0 * t * t) - (99 / 10.0 * t) + 17 / 5.0
        } else if (t < 9/10.0) {
            return (4356 / 361.0 * t * t) - (35442 / 1805.0 * t) + 16061 / 1805.0
        }
        
        return (54 / 5.0 * t * t) - (513 / 25.0 * t) + 268 / 25.0;
    }
    
    func animate() {
        fromValue = NSValue(cgPoint: CGPoint(x: 120, y: 32))
        toValue = NSValue(cgPoint: CGPoint(x: 120, y: 268))
        duration = 3.0
        timeOffset = 0.0
        
        timer?.invalidate()
        
        timer = Timer.scheduledTimer(timeInterval: 1/60.0, target: self, selector: #selector(step), userInfo: nil, repeats: true)
    }
    
    func step(timer: Timer) {
        timeOffset = min(timeOffset  + 1/60.0, duration)
        
        var time = timeOffset / duration
        time = TimeInterval(bounceEaseOut(t: CGFloat(time)))
        
        let position = interpolateFromValue(fromValue: fromValue, toValue: toValue, time: CGFloat(time))
        ballView.center = (position as? NSValue ?? NSValue(cgPoint: CGPoint.zero)).cgPointValue
        
        if timeOffset > duration {
            self.timer?.invalidate()
            self.timer = nil
        }
    }
}
