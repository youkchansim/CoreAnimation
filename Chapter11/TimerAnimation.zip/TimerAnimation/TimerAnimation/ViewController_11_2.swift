//
//  ViewController_11_2.swift
//  TimerAnimation
//
//  Created by Youk Chansim on 2017. 3. 12..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class ViewController_11_2: UIViewController {
    @IBOutlet weak var ballView: UIImageView!
    
    var timer: CADisplayLink?
    var duration: CFTimeInterval = 1.0
    var timeOffset: CFTimeInterval = 0.0
    var lastStep: CFTimeInterval = 0
    var fromValue: Any = NSValue(cgPoint: CGPoint(x: 150, y: 32))
    var toValue: Any = NSValue(cgPoint: CGPoint(x: 150, y: 268))

    override func viewDidLoad() {
        super.viewDidLoad()

        ballView.image = UIImage(named: "Ball")
        
        animate()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        animate()
    }
}

extension ViewController_11_2 {
    func interpolate(from: CGFloat, to: CGFloat, time: CGFloat) -> CGFloat {
        return (to - from) * time + from
    }
    
    func interpolateFromValue(fromValue: Any, toValue: Any, time: CGFloat) -> Any {
        if let fromPoint = fromValue as? CGPoint, let toPoint = toValue as? CGPoint {
            let result = CGPoint(x: interpolate(from: fromPoint.x, to: toPoint.x, time: time), y: interpolate(from: fromPoint.y, to: toPoint.y, time: time))
            return NSValue(cgPoint: result)
        }
        
        return time < 0.5 ? fromValue : toValue
    }
    
    func bounceEaseOut(t: CGFloat) -> CGFloat {
        if t < 4 / 11.0 {
            return (121 * t * t) / 16.0
        } else if (t < 8 / 11.0) {
            return (363 / 40.0 * t * t) - (99 / 10.0 * t) + 17 / 5.0
        } else if (t < 9/10.0) {
            return (4356 / 361.0 * t * t) - (35442 / 1805.0 * t) + 16061 / 1805.0
        }
        
        return (54 / 5.0 * t * t) - (513 / 25.0 * t) + 268 / 25.0;
    }
    
    func animate() {
        ballView.center = CGPoint(x: 150, y: 32)
        
        duration = 1.0
        timeOffset = 0.0
        fromValue = NSValue(cgPoint: CGPoint(x: 150, y: 32))
        toValue = NSValue(cgPoint: CGPoint(x: 150, y: 268))
        
        timer?.invalidate()
        
        lastStep = CACurrentMediaTime()
        timer = CADisplayLink(target: self, selector: #selector(step))
        timer?.add(to: RunLoop.main, forMode: .defaultRunLoopMode)
    }
    
    func step(timer: CADisplayLink) {
        let thisStep = CACurrentMediaTime()
        let stepDuration = thisStep - lastStep
        lastStep = thisStep
        
        timeOffset = min(timeOffset + stepDuration, duration)
        
        var time = timeOffset / duration
        time = CFTimeInterval(bounceEaseOut(t: CGFloat(time)))
        
        let position = interpolateFromValue(fromValue: fromValue, toValue: toValue, time: CGFloat(time))
        ballView.center = (position as? NSValue ?? NSValue(cgPoint: CGPoint.zero)).cgPointValue
        
        if timeOffset >= duration {
            self.timer?.invalidate()
            self.timer = nil
        }
    }
}
