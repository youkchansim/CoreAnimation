//
//  ViewController_11_3.swift
//  TimerAnimation
//
//  Created by Youk Chansim on 2017. 3. 13..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit
import QuartzCore

class Crate: UIImageView {
    let MASS: cpFloat = 100
    
    var body: UnsafeMutablePointer<cpBody>
    var shape: UnsafeMutablePointer<cpShape>
    
    override init(frame: CGRect) {
        body = cpBodyNew(MASS, cpMomentForBox(MASS, cpFloat(frame.size.width), cpFloat(frame.size.height)))
        
        let corners = [
            cpv(0, 0),
            cpv(0, cpFloat(frame.size.height)),
            cpv(cpFloat(frame.size.width), cpFloat(frame.size.height)),
            cpv(cpFloat(frame.size.width), 0),
        ]
        
        shape = cpPolyShapeNew(body, Int32(corners.count), UnsafeMutablePointer(mutating: corners), cpv(cpFloat(-frame.size.width) / 2, cpFloat(-frame.size.height) / 2))
        
        super.init(frame: frame)
        
        image = #imageLiteral(resourceName: "Crate")
        contentMode = UIViewContentMode.scaleAspectFill
        
        cpShapeSetFriction(shape, 0.5)
        cpShapeSetElasticity(shape, 0.8)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

class ViewController_11_3: UIViewController {
    @IBOutlet weak var containerView: UIView!
    
    let GRAVITY = 1000
    
    var space: UnsafeMutablePointer<cpSpace>?
    var timer: CADisplayLink?
    var lastStep: CFTimeInterval = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        containerView.layer.isGeometryFlipped = true
        
        space = cpSpaceNew()
        cpSpaceSetGravity(space, cpv(0, -(Float(GRAVITY))))
        
        let crate = Crate(frame: CGRect(x: 100, y: 0, width: 100, height: 100))
        containerView.addSubview(crate)
        
        cpSpaceAddBody(space, crate.body)
        cpSpaceAddShape(space, crate.shape)
        
        lastStep = CACurrentMediaTime()
        timer = CADisplayLink(target: self, selector: #selector(step))
        timer?.add(to: RunLoop.main, forMode: .defaultRunLoopMode)
    }
}

extension ViewController_11_3 {
    func updateShape(shape: UnsafeMutablePointer<cpShape>?, unused: UnsafeMutableRawPointer?) -> Void {
        let crate = shape?.pointee.data.assumingMemoryBound(to: Crate.self).pointee
        let body = shape?.pointee.body
        crate?.center = cpBodyGetPos(body)
        crate?.transform = CGAffineTransform(rotationAngle: CGFloat(cpBodyGetAngle(body)))
    }
    
    func step(timer: CADisplayLink) {
        let thisStep = CACurrentMediaTime()
        let stepDuration = thisStep - lastStep
        lastStep = thisStep
        
        cpSpaceStep(space, cpFloat(stepDuration))
        
        let b: cpSpaceShapeIteratorFunc = { shape, data in
            let crate = shape?.pointee.data.assumingMemoryBound(to: Crate.self).pointee
            let body = shape?.pointee.body
            crate?.center = cpBodyGetPos(body)
            crate?.transform = CGAffineTransform(rotationAngle: CGFloat(cpBodyGetAngle(body)))
        }
        
        cpSpaceEachShape(space, b, nil)
    }
}
