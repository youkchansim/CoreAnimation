//
//  ViewController.swift
//  SpecilzedLayer
//
//  Created by Youk Chansim on 2017. 2. 22..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var label: LayerLabel! {
        didSet {
            label.setText(text: "하하하하")
            label.setFont(font: UIFont.systemFont(ofSize: 15))
            label.setTextColor(color: .red)
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
//        let path = UIBezierPath()
//        path.move(to: CGPoint(x: 175, y: 100))
//        path.addArc(withCenter: CGPoint(x: 150, y: 100), radius: 25, startAngle: 0, endAngle: CGFloat(2.0 * M_PI), clockwise: true)
//        path.move(to: CGPoint(x: 150, y: 125))
//        path.addLine(to: CGPoint(x: 150, y: 175))
//        path.addLine(to: CGPoint(x: 125, y: 225))
//        path.move(to: CGPoint(x: 150, y: 175))
//        path.addLine(to: CGPoint(x: 175, y: 225))
//        path.move(to: CGPoint(x: 100, y: 150))
//        path.addLine(to: CGPoint(x: 200, y: 150))
//        
//        let shapeLayer = CAShapeLayer()
//        shapeLayer.strokeColor = UIColor.red.cgColor
//        shapeLayer.fillColor = UIColor.clear.cgColor
//        shapeLayer.lineWidth = 5
//        shapeLayer.lineJoin = kCALineJoinRound
//        shapeLayer.lineCap = kCALineCapRound
//        shapeLayer.path = path.cgPath
//        
//        containerView.layer.addSublayer(shapeLayer)
        
        let textLayer = CATextLayer()
        textLayer.frame = containerView.bounds
        containerView.layer.addSublayer(textLayer)
        
        textLayer.foregroundColor = UIColor.black.cgColor
        textLayer.alignmentMode = kCAAlignmentJustified
        textLayer.isWrapped = true
        
        let font = UIFont.systemFont(ofSize: 15)
        
        textLayer.font = font
        textLayer.fontSize = font.pointSize
        
        let text = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque massa arcu, eleifend vel varius in, facilisis pulvinar leo. Nunc quis nunc at mauris pharetra condimentum ut ac neque. Nunc elementum, libero ut porttitor dictum, diam odio congue lacus, vel fringilla sapien diam at purus. Etiam suscipit pretium nunc sit amet lobortis"
        
        let string = NSMutableAttributedString(string: text)
        var attributes: Dictionary<String, Any> = [
            kCTForegroundColorAttributeName as String: UIColor.black.cgColor,
            kCTFontAttributeName as String: font
        ]
        
        string.setAttributes(attributes, range: NSRange(location: 0, length: text.characters.count))
        
        attributes = [
        kCTForegroundColorAttributeName as String: UIColor.red.cgColor,
        kCTUnderlineStyleAttributeName as String: CTUnderlineStyle.single.rawValue,
        kCTFontAttributeName as String: font
        ]
        
        string.setAttributes(attributes, range: NSRange(location: 6, length: 5))
        
        textLayer.string = string
        textLayer.contentsScale = UIScreen.main.scale
    }
}

class LayerLabel: UILabel {
    override class var layerClass: AnyClass {
        return CATextLayer.self
    }
    
    var textLayer: CATextLayer? {
        return self.layer as? CATextLayer
    }
    
    func setUp() {
        text = text
        textColor = textColor
        font = font
        
        textLayer?.alignmentMode = kCAAlignmentJustified
        textLayer?.isWrapped = true
        
        layer.display()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUp()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        setUp()
    }
    
    func setText(text: String) {
        super.text = text
        textLayer?.string = text
    }
    
    func setTextColor(color: UIColor) {
        super.textColor = color
        textLayer?.foregroundColor = color.cgColor
    }
    
    func setFont(font: UIFont) {
        textLayer?.font = font
        textLayer?.fontSize = font.pointSize
    }
}
